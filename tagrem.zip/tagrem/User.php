<?php

class User{
	

public $attributes;

protected $name = NULL;
protected $username = NULL;
protected $password = NULL;
protected $confirm_password = NULL;
protected $zip = NULL;
protected $strErrormsgs = NULL;

protected $servername = "localhost";
protected $db_username = "root";
protected $db_password = "root";

protected $mysqli_conn;

function __construct()
{
	$this->mysqli_conn = new mysqli($this->servername, $this->db_username, $this->db_password, "tagrem_db");

	// Check connection
	if ($mysqli_conn->connect_error) {
	  die("Connection failed: " . $mysqli_conn->connect_error);
	}
	
}

public function setName( $name ){
	$this->name = $name;
}


public function getName(){
	return $this->name;
}


public function setUsername( $username ){
	$this->username = $username;
}


public function getUsername(){
	return $this->username;
}


public function setPassword( $password ){
	$this->password = $password;
}


public function getPassword(){
	return $this->password;
}


public function setConfirm_password( $confirm_password ){
	$this->confirm_password = $confirm_password;
}


public function getConfirm_password(){
	return $this->confirm_password;
}

public function setZip( $zip ){
	$this->zip = $zip;
}


public function getZip(){
	return $this->zip;
}

public function __isset($name)
{
	
}

public function validate()
{

	if( isset( $this->attributes ) ) 
	{
	
		foreach( $this->attributes as $key=>$value)
		{
			$setter = 'set'.ucfirst($key);
  		  	if(method_exists($this, $setter))
  		  	{
     		  $this->$setter($value);
  		  	}
		}
	}

	$boolisValid = true;
	if( empty ( $this->getName() ) ){
		$this->addError("Name field should not be blank.");
		$boolisValid = false;
	}


	if( empty ( $this->getUsername() ) ){
		$this->addError("Username field should not be blank.");
		$boolisValid = false;
	}


	if( empty ( $this->getPassword() ) ){
		$this->addError("Password field should not be blank.");
		$boolisValid = false;
	}

	if( empty ( $this->getConfirm_password() ) ){
		$this->addError("Confirm Password field should not be blank.");
		$boolisValid = false;
	}

	if( empty ( $this->getZip() ) ){
		$this->addError("Zip code field should not be blank.");
		$boolisValid = false;
	}

	if( $this->getPassword() != $this->getConfirm_password() ){
		$this->addError("Passwords are not same.");
		$boolisValid = false;
	}

	return $boolisValid; 
}

public function addError($strErrorMsg)
{
	$this->strErrormsgs[] = $strErrorMsg; 

}

public static function getErrorSummary( $objUser )
{
	$strMessages = "<div><p>Please fix below errors:</p><ul>";
	foreach($objUser->strErrormsgs as $strErrormsg) {
		$strMessages .= "<li>".$strErrormsg."</li>";
	}

	$strMessages .= "</ul></div>";
	return $strMessages; 
}

public function save()
{
	$this->mysqli_conn -> autocommit(FALSE);

	$strSql = "INSERT INTO user ( name, username, password, zip ) 
				VALUES('".$this->getName()."',
						'".$this->getUsername()."',
						'".$this->getPassword()."',
						'".$this->getZip()."'	
				)";

				
	$this->mysqli_conn -> query( $strSql );

	if (!$this->mysqli_conn -> commit()) {
	  echo "Commit transaction failed";
	  exit();
	}

	$this->mysqli_conn -> close();
	echo("User created successfully");
}



}
?>