<html>

<head> 
<title> Tagrem Registeration </title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body class="hold-transition register-page">
	
<div class="container">	
	<div class="register-box">
		<br/>
		 <div class="register-logo">
    		<h3 align="center"><b>Registeration Form</b></h3>
  		 </div>
		
		<div class="card">
    		<div class="card-body register-card-body">	
				<form name="userForm" action="submit.php" method="post">

					<div class="row form-group">	
						<div class="col-md-3">	
							Name:
						</div>
						<div class="col-md-9">	 
							<input class="form-control" type="text" name="userForm[name]">
						</div>
					</div>

					<div class="row form-group">	
						<div class="col-md-3">	
							Username:
						</div>
						<div class="col-md-9">	
						 	<input class="form-control" type="text" name="userForm[username]">
						</div>
					</div>

					<div class="row form-group">	
						<div class="col-md-3">	
							Password:
						</div>
						<div class="col-md-9">	 
						 <input class="form-control" type="password" name="userForm[password]">
						</div>
					</div>

					<div class="row form-group">	
						<div class="col-md-3">	
							Confirm Password: 
						</div>
						<div class="col-md-9">
							<input class="form-control" type="password" name="userForm[confirm_password]">
						</div>
					</div>
	
					<div class="row form-group">	
						<div class="col-md-3">		
							Zip Code: 
						</div>
						<div class="col-md-9">
							<input class="form-control" type="text" name="userForm[zip]">
						</div>
					</div>
		<div class="row">
			<div class="col-md-4"></div>	
			<div class="col-md-4"><input class="btn btn-primary" type="submit" value="SUBMIT"></div>
			<div class="col-md-4"></div>
		</div>	
</form>
</div>
</div>
</div>
</div>

</body>
</html>